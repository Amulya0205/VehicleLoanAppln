package com.Vehicleloan.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Vehicleloan.dao.ICustomerDao;
import com.Vehicleloan.model.Customer;
@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao customerDao;
	
	@Override
	public List<Customer> fetchPassword(String email) {
		
		return null;
	}

	@Override
	public void AddUser(Customer cust) {
	customerDao.AddUser(cust);
		
	}

}
