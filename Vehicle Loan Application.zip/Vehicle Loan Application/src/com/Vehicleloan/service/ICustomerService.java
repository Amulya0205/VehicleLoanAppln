package com.Vehicleloan.service;

import java.util.List;

import com.Vehicleloan.model.Customer;

public interface ICustomerService {

List<Customer> fetchPassword(String email);

void AddUser(Customer cust);
	
	
}
