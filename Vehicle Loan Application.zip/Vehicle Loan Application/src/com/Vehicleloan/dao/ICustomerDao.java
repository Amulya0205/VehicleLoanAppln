package com.Vehicleloan.dao;

import java.util.List;

import com.Vehicleloan.model.Customer;

public interface ICustomerDao {

public List<Customer> fetchPassword(String email);
	
	public void AddUser(Customer cust);
}
