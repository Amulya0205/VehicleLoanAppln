package com.Vehicleloan.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.Vehicleloan.model.Customer;
import com.Vehicleloan.service.ICustomerService;

@Controller
public class CustomerController {

	@Autowired
	ICustomerService customerService;

		@RequestMapping("/Login")
		public String showLoginView(Model modal)
		{
			modal.addAttribute("cust", new Customer());
			String view="LoginView";
			return view;
		}
		
		@RequestMapping(value="/registerPage",method=RequestMethod.POST)
		public String validateregistrationPage(@Valid @ModelAttribute("cust") 
		Customer cust ,BindingResult bindingResult,Model model,HttpServletRequest req)
		{
			String view="";
		if(bindingResult.hasErrors())
		{
			view="successPage";
			return view;
		}
		else
		{
			System.out.println(cust.getFirstname());
			customerService.AddUser(cust);
			
			view="successPage";
			return view;
			
		}
		}
		/*
		@RequestMapping("/Forgot")
		public String showForgetPassword(Model model,HttpServletRequest request)
		{
			model.addAttribute("useremail", new AuthorizationDetails());
			String view="ForgetPassword";
		
			return view;
		}
		
		@RequestMapping("/ForgotProcessing")
	public void  ProcessPassword(@RequestParam("email") String email ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		
			
			List<Customer> UserDetails=customerService.fetchPassword(email);
			//String view="success";
					
					
	}*/
}
